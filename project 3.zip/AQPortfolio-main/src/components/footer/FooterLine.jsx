const FooterLine = () => {
  return <div>FooterLine</div>;
};

export default FooterLine;
